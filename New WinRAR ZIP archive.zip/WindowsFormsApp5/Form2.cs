﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace WindowsFormsApp5
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }
        SqlConnection sql = new SqlConnection("Data Source=DESKTOP-LKUTE6J;Initial Catalog=Facebook;Integrated Security=True");

        WebBrowser wbr;
        WebBrowser wbr2;
        WebBrowser wbr3;
        WebBrowser wbr4;
        WebBrowser wbr5;
        WebBrowser wbr6;
        WebBrowser wbr7;
        WebBrowser wbr8;
        WebBrowser wbr9;


        List<string> getalldata = new List<string>();
        List<string> getallurl = new List<string>();


        private void Form2_Load(object sender, EventArgs e)
        {
            wbr = new WebBrowser();
            wbr.Visible = false;
            wbr.Size = this.Size;
            wbr.Navigate("www.facebook.com");
            wbr.DocumentCompleted += Wbr_DocumentCompleted;
            this.Controls.Add(wbr);
        }
        string name;
        Image imag;
        string getimg = "";
        string idd = "";
        string url = "https://www.facebook.com/profile.php?id=AAAAA&sk=friends&ft_ref=flsa";
        string activ = "https://www.facebook.com/profile.php?id=AAAAA&sk=allactivity&entry_point=profile_shortcut";
        private void Wbr_DocumentCompleted(object sender, WebBrowserDocumentCompletedEventArgs e)
        {
            try
            {

                HtmlElementCollection htm = wbr.Document.GetElementsByTagName("a");
                foreach (HtmlElement item in htm)
                {
                    if (item.GetAttribute("className").Equals("_2s25 _606w"))
                    {
                        idd = item.GetAttribute("href");
                        int index = idd.IndexOf("=") + 1;
                        idd = idd.Substring(index);
                        label8.Text = idd;
                        url = url.Replace("AAAAA", idd);
                        activ = activ.Replace("AAAAA", idd);
                    }

                }



                HtmlElementCollection html = wbr.Document.GetElementsByTagName("img");
                foreach (HtmlElement item in html)
                {
                    if (item.GetAttribute("className").Equals("_2qgu _7ql _1m6h img"))
                    {
                        getimg = item.GetAttribute("src");
                        var req = WebRequest.Create(getimg);
                        using (var res = req.GetResponse())
                        {
                            var stream = res.GetResponseStream();
                            pictureBox1.Image = Bitmap.FromStream(stream);
                            imag = pictureBox1.Image;
                        }
                        req = null;
                    }
                }
                html = null;

                HtmlElementCollection htm2 = wbr.Document.GetElementsByTagName("span");
                foreach (HtmlElement item1 in htm2)
                {
                    if (item1.GetAttribute("className").Equals("_1vp5"))
                    {
                        label1.Text = item1.InnerText;
                        name = label1.Text;
                    }


                }
                htm2 = null;
                wbr2 = new WebBrowser();
                wbr2.Visible = false;
                wbr2.Size = this.Size;
                wbr2.Navigate(url);
                wbr2.DocumentCompleted += Wbr2_DocumentCompleted;
                this.Controls.Add(wbr2);


            }
            catch { }
        }
        ArrayList fallowing = new ArrayList();
        string contn;
        private void Wbr2_DocumentCompleted(object sender, WebBrowserDocumentCompletedEventArgs e)
        {
            wbr.Dispose();

            try
            {
                var htm1 = wbr2.Document.GetElementsByTagName("span");

                foreach (HtmlElement item in htm1)
                {
                    if (item.GetAttribute("className").Equals("_gs6"))
                    {
                        fallowing.Add(Environment.NewLine + item.InnerText);
                        //  contn =item.InnerText;
                        label2.Text = "friends: " + item.InnerText;
                    }
                }
                foreach (HtmlElement item in htm1)
                {
                    if (item.GetAttribute("className").Equals("_51lp _5ugg _5ugh _3-99"))
                    {
                        fallowing.Add(Environment.NewLine + item.InnerText);
                        //  contn =item.InnerText;
                        label3.Text = "friend Requeste: " + item.InnerText;
                    }
                }

            }
            catch { }
            try
            {

                var html2 = wbr2.Document.GetElementsByTagName("div");
                foreach (HtmlElement item in html2)
                {
                    if (item.GetAttribute("className").Equals("fsl fwb fcb"))
                    {
                        foreach (HtmlElement item2 in item.GetElementsByTagName("a"))
                        {
                            if (!getalldata.Contains(item2.GetAttribute("href")))
                            {

                                getalldata.Add(item2.InnerText);
                                getallurl.Add(item2.GetAttribute("href"));
                            }
                        }

                    }

                }

                checkedListBox1.Items.Clear();
                wbr3 = new WebBrowser();
                wbr3.Visible = false;
                wbr3.Size = this.Size;
                wbr3.Navigate(activ);
                wbr3.DocumentCompleted += Wbr3_DocumentCompleted;
                this.Controls.Add(wbr3);

                for (int i = 0; i <= getalldata.Count; i++)
                {
                    checkedListBox1.Items.Add(getalldata[i]);
                }
            }
            catch { }

        }
        string activaty;
        private void Wbr3_DocumentCompleted(object sender, WebBrowserDocumentCompletedEventArgs e)
        {
            try
            {
                var htm1 = wbr3.Document.GetElementsByTagName("div");

                foreach (HtmlElement item in htm1)
                {
                    if (item.GetAttribute("className").Equals("_42ef"))
                    {

                        if (item.GetAttribute("className").Equals("_42ef"))
                        {

                            activaty = item.InnerText + "\n" + activaty;

                        }

                    }
                }
                textBox1.Text = activaty;
                wbr4 = new WebBrowser();
                wbr4.Visible = false;
                wbr4.Size = this.Size;
                wbr4.Navigate("https://www.facebook.com/groups/");
                wbr4.DocumentCompleted += Wbr4_DocumentCompleted;
                this.Controls.Add(wbr4);
            }
            catch { }

        }
        List<string> getalldata1 = new List<string>();
        string groubs;
        List<string> groups = new List<string>();
        private void Wbr4_DocumentCompleted(object sender, WebBrowserDocumentCompletedEventArgs e)
        {

            try
            {
                var html2 = wbr4.Document.GetElementsByTagName("a");
                foreach (HtmlElement item in html2)
                {
                    if (item.GetAttribute("className").Equals("_2yau"))
                    {
                        groubs = item.InnerText + "\n" + groubs;
                        groups.Add(item.InnerText);
                    }

                }

                textBox2.Text = groubs;

                wbr5 = new WebBrowser();
                wbr5.Visible = false;
                wbr5.Size = this.Size;
                wbr5.Navigate("https://www.facebook.com/pages/?category=liked");
                wbr5.DocumentCompleted += Wbr5_DocumentCompleted;
                this.Controls.Add(wbr5);
            }
            catch { }


        }
        string pages;
        List<string> pages1 = new List<string>();

        private void Wbr5_DocumentCompleted(object sender, WebBrowserDocumentCompletedEventArgs e)
        {
            try
            {
                var html2 = wbr5.Document.GetElementsByTagName("div");
                foreach (HtmlElement item in html2)
                {
                    if (item.GetAttribute("className").Equals("_7ywj fsl fwb fcb"))
                    {
                        pages = item.InnerText + "\n" + pages;
                        pages1.Add(item.InnerText);
                    }

                }
                textBox3.Text = pages;
                wbr6 = new WebBrowser();
                wbr6.Visible = false;
                wbr6.Size = this.Size;
                wbr6.Navigate("https://www.facebook.com/settings");
                wbr6.DocumentCompleted += Wbr6_DocumentCompleted;
                this.Controls.Add(wbr6);
            }
            catch { }
        }
        List<string> getalldata2 = new List<string>();
        string[] email;
        string email1;
        private void Wbr6_DocumentCompleted(object sender, WebBrowserDocumentCompletedEventArgs e)
        {
            try
            {
                var html2 = wbr6.Document.GetElementsByTagName("span");
                foreach (HtmlElement item in html2)
                {
                    if (item.GetAttribute("className").Equals("fbSettingsListItemContent fcg"))
                    {
                        getalldata2.Add(item.InnerText);
                    }

                }
                email = getalldata2.ToArray();

                label7.Text = email[2];
                email1 = label7.Text;

                wbr8 = new WebBrowser();
                wbr8.Visible = false;
                wbr8.Size = this.Size;
                wbr8.Navigate("https://www.facebook.com/messages/");
                wbr8.DocumentCompleted += Wbr8_DocumentCompleted;
                this.Controls.Add(wbr8);
            }
            catch { }
        }

        private void label1_Click(object sender, EventArgs e)
        {
            checkedListBox1.Items.Clear();
            checkedListBox2.Items.Clear();
            getalldata.Clear();

            var html3 = wbr2.Document.GetElementsByTagName("div");
            foreach (HtmlElement item in html3)
            {

                item.ScrollIntoView(false);
            }

            WebBrowserDocumentCompletedEventArgs f0 = new WebBrowserDocumentCompletedEventArgs(wbr2.Document.Url);
            Wbr2_DocumentCompleted(sender, f0);

        }

        private void label5_Click(object sender, EventArgs e)
        {
            textBox2.Clear();
            groups.Clear();
            var html3 = wbr4.Document.GetElementsByTagName("div");
            foreach (HtmlElement item in html3)
            {

                if (item.GetAttribute("className").Equals("_3qn7 _61-0 _2fyi _3qng"))
                {
                    item.InvokeMember("Click");
                }

            }

            WebBrowserDocumentCompletedEventArgs f = new WebBrowserDocumentCompletedEventArgs(wbr4.Document.Url);
            Wbr4_DocumentCompleted(sender, f);
        }

        private void label6_Click(object sender, EventArgs e)
        {
            pages1.Clear();
            textBox3.Clear();
            var html3 = wbr5.Document.GetElementsByTagName("div");
            foreach (HtmlElement item in html3)
            {

                item.ScrollIntoView(false);
            }

            WebBrowserDocumentCompletedEventArgs f = new WebBrowserDocumentCompletedEventArgs(wbr5.Document.Url);
            Wbr5_DocumentCompleted(sender, f);
        }

        private void button1_Click(object sender, EventArgs e)
        {

            foreach (int indexChecked in checkedListBox1.CheckedIndices)
            {

                string count = indexChecked.ToString();
                int count1 = int.Parse(count);
                wbr7 = new WebBrowser();
                wbr7.Visible = false;
                wbr7.Size = this.Size;
                wbr7.Navigate(getallurl[count1]);
                wbr7.DocumentCompleted += Wbr7_DocumentCompleted;
                this.Controls.Add(wbr7);


            }
        }
        string about = "";
        private void Wbr7_DocumentCompleted(object sender, WebBrowserDocumentCompletedEventArgs e)
        {

            var html2 = wbr7.Document.GetElementsByTagName("div");
            foreach (HtmlElement item in html2)
            {
                if (item.GetAttribute("className").Equals("_3-8t"))
                {
                    //   MessageBox.Show(item.InnerText);
                    about = item.InnerText + "\n" + about;
                }

            }
            textBox4.Text = about;


        }
        List<string> getchats = new List<string>();
        List<string> getchatsurl = new List<string>();

        private void Wbr8_DocumentCompleted(object sender, WebBrowserDocumentCompletedEventArgs e)
        {
            try
            {

                var html2 = wbr8.Document.GetElementsByTagName("div");
                foreach (HtmlElement item in html2)
                {
                    if (item.GetAttribute("className").Equals("_1qt5 _5l-3"))
                    {
                        getchats.Add(item.InnerText);

                    }
                }
                var html3 = wbr8.Document.GetElementsByTagName("a");
                foreach (HtmlElement item in html3)
                {
                    if (item.GetAttribute("className").Equals("_1ht5 _2il3 _6zka _5l-3 _3itx"))
                    {
                        getchatsurl.Add(item.GetAttribute("data-href"));
                    }
                }


                checkedListBox2.Items.Clear();
                for (int i = 0; i <= getchats.Count; i++)
                {
                    checkedListBox2.Items.Add(getchats[i]);
                }


            }
            catch { }

        }

        private void button2_Click(object sender, EventArgs e)
        {


            //      long id = 1;
            //      SqlCommand sqlcom = new SqlCommand("insert into users1 values (" + id + ",'" + name + "','" + pictureBox1.Image + "','" + email + "') ", sql);
            //  sql.Open();
            //  sqlcom.ExecuteNonQuery();
            //  SqlCommand sqlcom1 = new SqlCommand("insert into usersfriends values (" + id + ",'" + email + "') ", sql);

            //  string strSQL = "insert into usersfriends values (" + id + ",'" + "@val" + "')";
            //  using (SqlCommand command = new SqlCommand(strSQL, sql))
            //  {
            //      command.Parameters.AddWithValue("@val", "");                foreach (string service in getalldata)
            //      {
            //          command.Parameters["@val"].Value = service;
            //          command.ExecuteNonQuery();
            //      }
            //  }
            //  MessageBox.Show("done");

            ////  sqlcom1.ExecuteNonQuery();
            //  sql.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            //try
            //{
            //    int id = 1;
            //    SqlCommand sqlcom = new SqlCommand("insert into users1 values (" + id + ",'" + '@' + label1.Text + "','" + pictureBox1.Image + "','" + label7.Text + "') ", sql);
            //    sql.Open();
            //    sqlcom.ExecuteNonQuery();

            //    for (int i = 0; i < getalldata.Count; i++)
            //    {
            //        if(getalldata[i] == "Møh Ŕòç'ķň")
            //        {
            //            continue;
            //        }

            //        SqlCommand sqlcom1 = new SqlCommand("insert into usersfriends values (" + id + ",'" +'@'+ getalldata[i] + "')", sql);
            //        sqlcom1.ExecuteNonQuery();                   
            //    }

            //    for (int i = 0; i < groups.Count; i++)
            //    {
            //        SqlCommand sqlcom2 = new SqlCommand("insert into usersgroups values (" + id + ",'" +'@'+ groups[i] + "')", sql);
            //        sqlcom2.ExecuteNonQuery();
            //    }

            //    for (int i = 0; i < pages1.Count; i++)
            //    {
            //        SqlCommand sqlcom3 = new SqlCommand("insert into userspages values (" + id + ",'" + '@'+pages1[i] + "')", sql);
            //        sqlcom3.ExecuteNonQuery();
            //    }
            //    MessageBox.Show("done");

            //    //  sqlcom1.ExecuteNonQuery();
            //    sql.Close();
            //}
            //catch (Exception ex)
            //{
            //    MessageBox.Show(ex.ToString());
            //}

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void label9_Click(object sender, EventArgs e)
        {
            checkedListBox2.Items.Clear();
            getchats.Clear();
            var html4 = wbr8.Document.GetElementsByTagName("div");
            foreach (HtmlElement item in html4)
            {

                item.ScrollIntoView(false);

            }

            WebBrowserDocumentCompletedEventArgs f1 = new WebBrowserDocumentCompletedEventArgs(wbr8.Document.Url);
            Wbr8_DocumentCompleted(sender, f1);
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            foreach (int indexChecked in checkedListBox2.CheckedIndices)
            {

                string count = indexChecked.ToString();
                int count1 = int.Parse(count);
                wbr9 = new WebBrowser();
                wbr9.Visible = false;
                wbr9.Size = this.Size;
                wbr9.Navigate(getchatsurl[count1]);
                wbr9.DocumentCompleted += Wbr9_DocumentCompleted;
                this.Controls.Add(wbr9);


            }
        }

        private void Wbr9_DocumentCompleted(object sender, WebBrowserDocumentCompletedEventArgs e)
        {
            var html4 = wbr9.Document.GetElementsByTagName("div");
            foreach (HtmlElement item in html4)
            {
                if (item.GetAttribute("className").Equals("_4_j4"))
                {

                    textBox6.Text = item.InnerText;
                }
            }

        }

    }
}