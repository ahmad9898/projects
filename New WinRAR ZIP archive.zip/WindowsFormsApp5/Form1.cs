﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp5
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void webBrowser1_DocumentCompleted(object sender, WebBrowserDocumentCompletedEventArgs e)
        {
            try
            {
                if (e.Url.AbsoluteUri.Equals("https://www.facebook.com/"))
                {
                    HtmlElement el = webBrowser1.Document.GetElementById("pass");
                if (el == null)
                {
                    Form2 fr2 = new Form2();
                    fr2.Show();
                        this.Hide();
                }
                else
                {
                    MessageBox.Show("you must log in first");
                }


            }
            }
            catch { }
        }
    }
}
